{{ define "sibli.job" }}
---
apiVersion: batch/v1
kind: Job
metadata:
    {{ if .useGenerateName }}
    generateName: {{.name}}-
    {{ else }}
    {{/*
      Name carries BOTH the image tag and a digest of the envs. A Job's
      spec.template is immutable, and the pod template below annotates it with
      sha256(envs) -- so a values-only env change with the tag unchanged would
      otherwise re-render the SAME name with a DIFFERENT template. Argo's
      server-side-apply dry-run then fails with "spec.template: field is
      immutable", which breaks diff calculation and puts the whole app in
      SYNC STATUS Unknown (seen on prod-l4pd 2026-08-04).
      The name+tag half is truncated first so the digest always survives the
      62-char cap -- a trailing substr could otherwise chop it off and
      reintroduce the collision.
    */}}
    name: {{ printf "%s-%s" (printf "%s-%s" .name .image.tag | substr 0 53) (.envs | toJson | sha256sum | trunc 8) }}
    {{ end }}
    labels:
        {{- include "sibli.labels" . | nindent 8 }}
    annotations:
    {{ range $key, $val := .annotations }}
        {{ $key }}: "{{ $val }}"
    {{ end }}
spec:
    backoffLimit: {{ .backoffLimit | default 1 }}
    {{ if .ttlSecondsAfterFinished }}
    ttlSecondsAfterFinished: {{ .ttlSecondsAfterFinished }}
    {{ end }}
    template:
        metadata:
            labels:
                {{- include "sibli.labels" . | nindent 16 }}
            annotations:
                sibli-checksums/envs: "{{ .envs | toJson | sha256sum }}"
                {{- /* Pod-only; `.annotations` above stays on the Job (Argo sync-options). */}}
                {{- range $key, $value := (.podAnnotations | default (dict)) }}
                {{ $key | quote }}: {{ $value | quote }}
                {{- end }}
        spec:
            restartPolicy: Never
            serviceAccountName: {{ .serviceAccountName }}
            {{- if .shareProcessNamespace }}
            shareProcessNamespace: true
            {{- end }}
            {{ if .credentials.containerRegistry }}
            imagePullSecrets:
              - name: {{ .credentials.containerRegistry.secretName }}
            {{ else if .imagePullSecrets }}
            imagePullSecrets:
                {{ .imagePullSecrets | toYaml | nindent 16 }}
            {{ end  }}
            {{- if .volumes }}
            volumes:
                {{ range $k, $v := .volumes }}
                -   name: "{{ $k }}"
                    {{ $v.from | toYaml | nindent 20 }}
                {{ end }}
            {{ end -}}
            {{ include "sibli.deploy.shared.template.spec.nodeSelectors" . | nindent 6 }}
            {{- if or .useDBWaiter (and .postgresSidecar .postgresSidecar.enabled) (and .snapshotBefore .snapshotBefore.enabled) }}
            initContainers:
                {{- if and .snapshotBefore .snapshotBefore.enabled }}
                {{- if eq .snapshotBefore.type "aws-rds-aurora" }}
                -   name: snapshot-db
                    image: "{{ required "snapshotBefore.image is required" .snapshotBefore.image }}"
                    {{- if .snapshotBefore.resources }}
                    resources:
                        {{- toYaml .snapshotBefore.resources | nindent 22 }}
                    {{- end }}
                    envFrom:
                        -   secretRef:
                                name: ml-shared-secrets
                        -   secretRef:
                                name: {{.deployType}}-{{.name}}-envs
                        {{ if .envFrom }}
                        {{- range $i, $val := .envFrom }}
                        -   secretRef:
                                name: {{ $val }}
                        {{ end -}}
                        {{ end }}
                    command:
                        - "sh"
                        - "-c"
                        - |
                          {{- include "sibli.job.snapshotBefore.awsRdsAurora.script" .snapshotBefore.awsRdsAurora | nindent 26 }}
                {{- else }}
                {{- fail (printf "mainStack.dbMigrationJobs.snapshotBefore.type %q is not implemented; add a branch in jobs.tpl or disable snapshotBefore" .snapshotBefore.type) }}
                {{- end }}
                {{- end }}
                {{- if and .postgresSidecar .postgresSidecar.enabled }}
                - name: postgres
                  image: "{{ .postgresSidecar.image.repo }}:{{ .postgresSidecar.image.tag }}"
                  imagePullPolicy: {{ .postgresSidecar.image.pullPolicy }}
                  restartPolicy: Always
                  resources:
                      {{- toYaml .postgresSidecar.resources | nindent 22 }}
                  {{- if (or .postgresSidecar.envs .postgresSidecar.envValueFrom) }}
                  env:
                      {{- if .postgresSidecar.envs }}
                      {{- range $key, $val := .postgresSidecar.envs }}
                      - name: {{ $key }}
                        value: "{{ $val }}"
                      {{- end }}
                      {{- end }}
                      {{- if .postgresSidecar.envValueFrom }}
                      {{- range $key, $val := .postgresSidecar.envValueFrom }}
                      - name: {{ $key }}
                        valueFrom:
                            {{ $val | toYaml | nindent 28 }}
                      {{- end }}
                      {{- end }}
                  {{- end }}
                  {{- if .postgresSidecar.ports }}
                  ports:
                      {{- toYaml .postgresSidecar.ports | nindent 22 }}
                  {{- end }}
                  {{- if .postgresSidecar.volumeMounts }}
                  volumeMounts:
                      {{- toYaml .postgresSidecar.volumeMounts | nindent 22 }}
                  {{- end }}
                {{- end }}
                {{- if .useDBWaiter }}
                -   name: wait-for-db
                    image: busybox
                    command:
                        - "sh"
                        - "-c"
                        - "until nc -z $POSTGRES_HOST ${POSTGRES_PORT:-5432} > /dev/null; do echo Waiting for $POSTGRES_HOST:${POSTGRES_PORT:-5432}; sleep 2; done;"
                    envFrom:
                        -   secretRef:
                                name: ml-shared-secrets
                        -   secretRef:
                                name: {{.deployType}}-{{.name}}-envs
                        {{ if .envFrom }}
                        {{- range $i, $val := .envFrom }}
                        -   secretRef:
                                name: {{ $val }}
                        {{ end -}}
                        {{ end }}
                {{- end }}
            {{- end }}
            containers:
                {{- range .sidecars }}
                - name: {{ .name }}
                  image: "{{ .image }}:{{ .imageTag | default "latest" }}"
                  imagePullPolicy: {{ .imagePullPolicy }}
                  resources:
                      {{- toYaml .resources | nindent 22 }}
                  {{- if (or .envs .envValueFrom) }}
                  env:
                      {{- if .envs }}
                      {{- range $key, $val := .envs }}
                      - name: {{ $key }}
                        value: "{{ $val }}"
                      {{- end }}
                      {{- end }}
                      {{- if .envValueFrom }}
                      {{- range $key, $val := .envValueFrom }}
                      - name: {{ $key }}
                        valueFrom:
                            {{ $val | toYaml | nindent 28 }}
                      {{- end }}
                      {{- end }}
                  {{- end }}
                  {{ if .command }}
                  command:
                        {{- range $_, $val := .command }}
                        - {{ $val }}
                        {{ end }}
                  {{ end }}
                  {{ if .args }}
                  args:
                        {{- range $_, $val := .args }}
                        - {{ $val }}
                        {{ end }}
                  {{ end }}
                  {{- if .ports }}
                  ports:
                      {{- toYaml .ports | nindent 22 }}
                  {{- end }}
                  {{- if .volumeMounts }}
                  volumeMounts:
                      {{- toYaml .volumeMounts | nindent 22 }}
                  {{- end }}
                {{- end }}
                -   name: main
                    image: "{{ .image.repo }}:{{ .image.tag }}"
                    imagePullPolicy: {{ .image.pullPolicy }}
                    {{- if .securityContext }}
                    securityContext:
                        {{- toYaml .securityContext | nindent 24 }}
                    {{- end }}
                    {{- if .volumeMounts }}
                    volumeMounts:
                    {{ range $k, $v := .volumeMounts }}
                        -   name: "{{$k}}"
                            mountPath: "{{$v.mountPath}}"
                            {{ if .subPath }}
                            subPath: "{{$v.subPath}}"
                            {{ end }}
                    {{ end -}}
                    {{ end }}
                    resources:
                        {{- toYaml .resources | nindent 26 }}
                    command:
                        - {{ .cmd }}
                    args:
                        {{- range $_, $val := .args }}
                        - {{ $val }}
                        {{ end }}
                    {{ if (or .envsFromFieldPath .env) }}
                    env:
                        {{ range $k, $v := (.envsFromFieldPath | default dict) }}
                        - name: {{ $k | quote }}
                          valueFrom:
                            fieldRef:
                              fieldPath: {{$v}}
                        {{ end }}
                        {{ range $k, $v := (.env | default dict) }}
                        - name: {{ $k | quote }}
                          value: {{ $v | quote }}
                        {{ end }}
                    {{ end }}

                    envFrom:
                        -   secretRef:
                                name: ml-shared-secrets
                        -   secretRef:
                                name: {{.deployType}}-{{.name}}-envs
                        {{ if .envFrom }}
                        {{- range $i, $val := .envFrom }}
                        -   secretRef:
                                name: {{ $val }}
                        {{ end -}}
                        {{ end }}
{{ end }}

{{- define "sibli.job.snapshotBefore.awsRdsAurora.script" -}}
set -euo pipefail
CLUSTER_ID=$(aws ssm get-parameter \
  --name "{{ required "snapshotBefore.awsRdsAurora.ssmPath is required" .ssmPath }}" \
  --with-decryption \
  --query 'Parameter.Value' --output text)
# strip trailing hyphens — AWS rejects snapshot ids containing `--`
SNAPSHOT_ID="{{ .namePrefix | default "pre-migration" }}-$(echo "$CLUSTER_ID" | cut -c1-30 | sed 's/-*$//')-$(date -u +%Y%m%d%H%M%S)"
echo "Creating cluster snapshot $SNAPSHOT_ID of $CLUSTER_ID"
aws rds create-db-cluster-snapshot \
  --db-cluster-identifier "$CLUSTER_ID" \
  --db-cluster-snapshot-identifier "$SNAPSHOT_ID"
DEADLINE=$(( $(date +%s) + {{ .waitTimeoutSeconds | default 3600 }} ))
while true; do
  STATUS=$(aws rds describe-db-cluster-snapshots \
    --db-cluster-snapshot-identifier "$SNAPSHOT_ID" \
    --query 'DBClusterSnapshots[0].Status' --output text)
  ELAPSED=$(( $(date +%s) - (DEADLINE - {{ .waitTimeoutSeconds | default 3600 }}) ))
  echo "Snapshot $SNAPSHOT_ID status=$STATUS elapsed=${ELAPSED}s"
  case "$STATUS" in
    (available) break ;;
    (creating) ;;
    (*) echo "Snapshot reached non-recoverable status: $STATUS"; exit 1 ;;
  esac
  if [ "$(date +%s)" -ge "$DEADLINE" ]; then
    echo "Timed out after {{ .waitTimeoutSeconds | default 3600 }}s waiting for $SNAPSHOT_ID"
    exit 1
  fi
  sleep 15
done
{{- end }}
