{{ define "sibli.internal-monitoring.cm" }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: ray-monitoring-config
  namespace: {{ .Release.Namespace }}
data:
  blackbox.yml: |
    modules:
      http_2xx:
        prober: http
        timeout: 5s
        http:
          method: GET

  ping-exporter-config.yml: |
    targets:
      {{ range $k, $v := .Values.mainStack.endpoints}}
      {{ if $v.enabled }}
      - ray-api-{{ $k }}.{{ $.Release.Namespace }}.svc.cluster.local
      {{ end}}
      {{ end }}
      - ray-frontend.{{ .Release.Namespace }}.svc.cluster.local
    ping:
      interval: 2s
      timeout: 3s
      history-size: 42
      payload-size: 120
    options:
      disableIPv6: false

  prometheus.yml: |
    scrape_configs:
      - job_name: 'blackbox'
        metrics_path: /probe
        params:
          module: [http_2xx]
        static_configs:
          - targets:
            {{ range $k, $v := .Values.mainStack.endpoints}}
            {{- if $v.enabled }}
            - ray-api-{{ $k }}.{{ $.Release.Namespace }}.svc.cluster.local
            {{ end -}}
            {{ end }}
        relabel_configs:
          - source_labels: [__address__]
            target_label: __param_target
          - target_label: instance
            source_labels: [__param_target]
          - target_label: __address__
            replacement: localhost:9115

    rule_files:
      - "/etc/prometheus/alert.rules.yml"
    alerting:
      alertmanagers:
        - static_configs:
            - targets:
                - "localhost:9093"
    
    
{{ .Values.tools.internalMonitoring.prometheus.config | toYaml | indent 4 }}

  alert.rules.yml: |
    groups:
      - name: blackbox_exporter_alerts
        rules:
          - alert: ServiceDown
            expr: probe_success == 0
            for: {{ .Values.tools.internalMonitoring.prometheus.alertRules.for }}
            labels:
              severity: critical
            annotations:
              summary: "Service {{`{{ $labels.instance }}`}} is down"
              description: "HTTP probe failed for {{`{{ $labels.instance }}`}}."

  alertmanager.yml: |
{{ .Values.tools.internalMonitoring.alertmanager.config | toYaml | indent 4 }}

  Caddyfile: |
    :80 {
      basic_auth {
        {{ .Values.tools.internalMonitoring.caddy.auth.user }} {{ .Values.tools.internalMonitoring.caddy.auth.hashedPassword }}
      }
      route {{.Values.tools.internalMonitoring.caddy.prefix}}/prometheus* {
        reverse_proxy localhost:9090
      }

      route {{.Values.tools.internalMonitoring.caddy.prefix}}/alertmanager* {
        reverse_proxy localhost:9093
      }
      redir {{.Values.tools.internalMonitoring.caddy.prefix}} {{.Values.tools.internalMonitoring.caddy.prefix}}/
      route {{.Values.tools.internalMonitoring.caddy.prefix}}/ {
        header Content-Type text/html
        respond <<HTML
          <!DOCTYPE html>
          <html lang="en">
          <head>
            <meta charset="UTF-8" />
            <title>Sibli Monitoring</title>
          </head>
          <body>
            <h1>Sibli Monitoring 💻</h1>
            <ul>
              <li><a href="{{.Values.tools.internalMonitoring.caddy.prefix}}/prometheus">Prometheus</a></li>
              <li><a href="{{.Values.tools.internalMonitoring.caddy.prefix}}/alertmanager">Alertmanager</a></li>
            </ul>
          </body>
          </html>
          HTML 200
      }
    }
{{ end }}