{{ define "sibli.internal-monitoring.svc" }}
---
apiVersion: v1
kind: Service
metadata:
    name: ray-monitoring
    namespace: {{ .Release.Namespace }} 
    annotations:
        {{ .Values.tools.internalMonitoring.serviceAnnotations | toYaml | nindent 8 }}
spec:
    type: {{ .Values.tools.internalMonitoring.serviceType }}
    selector:
        {{ .labels | toYaml | nindent 8 }}
    ports:
        -   protocol: TCP
            port: 80
            targetPort: 80
            name: caddy
        -   protocol: TCP
            port: 9090
            targetPort: 9090
            name: prometheus
        -   protocol: TCP
            port: 9093
            targetPort: 9093
            name: alertmanager
{{ end }}