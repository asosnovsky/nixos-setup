{{ define "sibli.internal-monitoring.deploy" }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
    name: ray-monitoring
    namespace: {{ .Release.Namespace}}
    annotations:
        {{ .annotations | toYaml | nindent 8 }}
    labels:
        {{ .labels | toYaml | nindent 8 }}
spec:
    replicas: 1
    selector:
        matchLabels:
            {{ .labels | toYaml | nindent 12 }}
    template:
        metadata:
            labels:
                {{ .labels | toYaml | nindent 16 }}
            annotations:
                {{ .annotations | toYaml | nindent 16 }}
        spec:
            containers:
                -   name: blackbox-exporter
                    image: {{ .Values.tools.internalMonitoring.image.blackboxExporter }}
                    ports:
                        - containerPort: 9115
                    volumeMounts:
                        -   name: ray-monitoring-config
                            mountPath: /etc/blackbox_exporter/blackbox.yml
                            subPath: blackbox.yml
                            readOnly: true

                -   name: prometheus
                    image: "{{ .Values.tools.internalMonitoring.image.prometheus }}"
                    args:
                        - '--config.file=/etc/prometheus/prometheus.yml'
                        - '--storage.tsdb.retention.time={{ .Values.tools.internalMonitoring.prometheus.retentionTime }}'
                        - '--web.external-url={{ .Values.tools.internalMonitoring.caddy.prefix }}/prometheus/'
                        - '--web.route-prefix={{ .Values.tools.internalMonitoring.caddy.prefix }}/prometheus/'
                    ports:
                        - containerPort: 9090
                    env:
                        {{ range $key, $value := .Values.tools.internalMonitoring.shared.env }}
                        -   name: "{{ $key }}"
                            value: "{{ $value }}"
                        {{ end }}
                    envFrom:
                        {{ .Values.tools.internalMonitoring.prometheus.envFrom | toYaml | nindent 24 }}
                    volumeMounts:
                        -   name: ray-monitoring-config
                            mountPath: /etc/prometheus/prometheus.yml
                            subPath: prometheus.yml
                            readOnly: true
                        -   name: ray-monitoring-config
                            mountPath: /etc/prometheus/alert.rules.yml
                            subPath: alert.rules.yml
                            readOnly: true

                -   name: alertmanager
                    image: "{{ .Values.tools.internalMonitoring.image.alertmanager }}"
                    args:
                        - '--config.file=/etc/alertmanager/alertmanager.yml'
                        - '--storage.path=/alertmanager'
                        - '--web.route-prefix={{ .Values.tools.internalMonitoring.caddy.prefix }}/alertmanager/'
                    env:
                        {{ range $key, $value := .Values.tools.internalMonitoring.shared.env }}
                        -   name: "{{ $key }}"
                            value: "{{ $value }}"
                        {{ end }}
                    ports:
                        - containerPort: 9093
                    envFrom:
                        {{ .Values.tools.internalMonitoring.alertmanager.envFrom | toYaml | nindent 28 }}
                    volumeMounts:
                        -   name: ray-monitoring-config
                            mountPath: /etc/alertmanager/alertmanager.yml
                            subPath: alertmanager.yml
                            readOnly: true

                -   name: caddy
                    image: "{{ .Values.tools.internalMonitoring.image.caddy }}"
                    ports:
                        - containerPort: 80
                    env:
                        {{ range $key, $value := .Values.tools.internalMonitoring.shared.env }}
                        -   name: "{{ $key }}"
                            value: "{{ $value }}"
                        {{ end }}
                    volumeMounts:
                        -   name: ray-monitoring-config
                            mountPath: /etc/caddy/Caddyfile
                            subPath: Caddyfile
                            readOnly: true

            volumes:
                -   name: ray-monitoring-config
                    configMap:
                        name: ray-monitoring-config
{{ end }}