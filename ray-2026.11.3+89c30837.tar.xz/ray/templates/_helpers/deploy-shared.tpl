
{{ define "sibli.deploy.shared.spec" }}
{{- /* KEDA owns the sandbox pool's replica count. */}}
{{ if eq .deployType "sandbox" }}
{{ else if .globals.scaleToZero }}
  replicas: 0
{{ else if .autoScaling.enabled }}
{{ else }}
  replicas: {{ .replicas }}
{{ end }}
  revisionHistoryLimit: {{ .revisionHistoryLimit | default 2 }}
  selector:
    matchLabels:
      {{- include "sibli.labels" . | nindent 6 }}
{{ end }}

{{ define "sibli.deploy.shared.template" }}
    metadata:
      labels:
        {{- include "sibli.labels" . | nindent 8 }}
      annotations:
        sibli-checksums/envs: "{{ .envs | toJson | sha256sum }}"
        {{ if .annotations }}
        {{- range $key, $value := .annotations }}
        {{ $key }}: "{{ $value }}"
        {{- end }}
        {{ end }}
{{ end }}

{{ define "sibli.deploy.shared.template.spec" }}
      {{- if .runtimeClassName }}
      runtimeClassName: {{ .runtimeClassName }}
      {{- end }}
      serviceAccountName: {{ .serviceAccountName }}
      {{ if .credentials.containerRegistry }}
      imagePullSecrets:
        - name: {{ .credentials.containerRegistry.secretName }}
      {{ else if .imagePullSecrets }}
      imagePullSecrets:
        {{ .imagePullSecrets | toYaml | nindent 9 }}
      {{ end  }}

      {{ if (or .volumes $.globals.flags.enableFilesForSecrets) }}
      volumes:

        {{ if .volumes }}
          {{ range $k, $v := .volumes }}
          - name: "{{ $k }}"
            {{ $v.from | toYaml | nindent 12 }}
          {{ end }}
        {{ end }}

        {{ if $.globals.flags.enableFilesForSecrets }}
          - name: "secrets"
            projected:
              sources:
                - secret:
                    name: "ml-shared-secrets"

          {{ if (not (eq .deployType "frontend"))}}
                - secret:
                    name: "{{.deployType}}-{{.name}}-envs"
          {{ end }}

          {{ if .envFrom }}
            {{ range $i, $val := .envFrom }}
                - secret:
                    name: "{{ $val }}"
            {{ end }}
          {{ end }}
        {{ end }}

      {{ end }}

      {{ if .initContainers }}
      initContainers:
        {{ toYaml .initContainers | nindent 9 }}
      {{ end }}

{{ include "sibli.deploy.shared.template.spec.nodeSelectors" . }}
{{ end }}

{{ define "sibli.deploy.shared.template.spec.nodeSelectors" }}
      {{ if .nodeSelector }}
      nodeSelector:
        {{ toYaml .nodeSelector | nindent 8 }}
      {{ end }}
      {{ if .tolerations }}
      tolerations:
        {{- toYaml .tolerations | nindent 8 }}
      {{ end }}
      {{ if .affinity }}
      affinity:
        {{- toYaml .affinity | nindent 8 }}
      {{ end }}
{{ end }}

{{ define "sibli.deploy.shared.container" }}
          image: "{{ .image.repo }}:{{ .image.tag }}"
          imagePullPolicy: {{ .image.pullPolicy }}
          {{- if (or .volumes $.globals.flags.enableFilesForSecrets) }}
          volumeMounts:

          {{ range $k, $v := (.volumes | default (dict)) }}
              - name: "{{$k}}"
                mountPath: "{{$v.mountPath}}"
                {{ if $v.subPath }}
                subPath: "{{$v.subPath}}"
                {{ end }}
                {{ if $v.readOnly }}
                readOnly: {{$v.readOnly}}
                {{ end }}
          {{ end -}}

          {{ if $.globals.flags.enableFilesForSecrets }}
              - name: "secrets"
                mountPath: "/ray/secrets"
                readOnly: true
          {{ end }}

          {{ end }}
          resources:
            {{- toYaml .resources | nindent 12 }}
          {{ if .command }}
          command:
            {{ toYaml .command | nindent 12 }}
          {{ end }}
          {{ if .args }}
          args:
            {{ toYaml .args | nindent 12 }}
          {{ end }}
          {{ if (or (not $.globals.flags.enableFilesForSecrets) .envFrom) }}
          envFrom:
            - secretRef:
                name: ml-shared-secrets
            {{ if (not (eq .deployType "frontend"))}}
            - secretRef:
                name: {{.deployType}}-{{.name}}-envs
            {{ end }}

            {{ if .envFrom }}
                {{- range $i, $val := .envFrom }}
            - secretRef:
                name: {{ $val }}
                {{ end -}}
            {{ end }}
          {{ end }}
{{ end }}

{{- define "sibli.sidecar" -}}
-   name: "{{ .name }}"
    image: "{{ .image.repo }}:{{ .image.tag }}"
    imagePullPolicy: {{ .image.pullPolicy }}
    {{ if .command }}
    command:
      {{ toYaml .command | nindent 6 }}
    {{ end }}
    resources:
    {{- toYaml .resources | nindent 6 }}
    {{- if (or .envs .envValueFrom) }}
    env:
    {{ if .envs }}
    {{- range $key, $val := .envs }}
        -   name: {{ $key }}
            value: "{{ $val }}"
    {{ end }}
    {{ end }}
    {{ if .envValueFrom }}
    {{- range $key, $val := .envValueFrom }}
        -   name: {{ $key }}
            valueFrom:
              {{ $val | toYaml | nindent 14 }}
    {{ end }}
    {{ end }}
    {{- end -}}
    {{- if .ports }}
    ports:
        {{- range $key, $val := .ports }}
        -   containerPort: {{ $val }}
            name: {{ $key }}
        {{ end }}
    {{- end -}}
{{- end -}}

{{- define "sibli.sidecars" -}}
{{- $commonStartState := (deepCopy .defaults) -}}
{{ range $key, $val := .sideCars -}}
{{- $state := (deepCopy $val) -}}
{{ if (not $val.independentSidecar) }}
{{- $state := (deepCopy $commonStartState | mustMerge (deepCopy $val)) -}}
{{ end }}
{{- $_ := (set $state "name" (replace "_" "-" $key)) -}}
{{- include "sibli.sidecar" $state -}}
{{- end -}}
{{- end -}}

{{ define "sibli.shared.envs" }}
{{ $enabled_worker_modules := list }}
{{ range $component, $componentStatus := .components }}
  {{ if $componentStatus }}
  {{ $enabled_worker_modules = append $enabled_worker_modules $component }}
  {{ end }}
{{ end }}
-   name: FF_enabled_worker_modules
    value: |-
      {{ $enabled_worker_modules | toJson }}
{{- /*
  App-side harness config. Only fields on HarnessConfiguration: the app ignores
  unknown SIBLI_CONFIG_HARNESS__* keys silently.
*/}}
{{- if .harness.enabled }}
-   name: SIBLI_CONFIG_HARNESS__ENABLED
    value: "true"
-   name: SIBLI_CONFIG_HARNESS__WORKSPACE_DIRECTORY
    value: "{{ .harness.workspaceDirectory }}"
-   name: SIBLI_CONFIG_HARNESS__MCP_URL
    value: "{{ include "sibli.harness.mcpUrl" . }}"
-   name: SIBLI_CONFIG_HARNESS__RUNTIMES
    value: |-
      {{ .harness.runtimes | toJson }}
{{- /* Top-level config, read by the MCP artifact tools; unset leaves them disabled. */}}
{{- if .harness.artifactRootPath }}
-   name: SIBLI_CONFIG_agent_artifact_root_path
    value: "{{ .harness.artifactRootPath }}"
{{- end }}
{{- end }}
{{ end }}

{{/* MCP server the sandboxed agent calls; `.harness.mcp.url` overrides. */}}
{{- define "sibli.harness.mcpUrl" -}}
{{- if .harness.mcp.url -}}
{{ .harness.mcp.url }}
{{- else -}}
http://ray-mcp-{{ .harness.mcp.serviceName }}.{{ .Release.Namespace }}.svc.cluster.local{{ .harness.mcp.path }}
{{- end -}}
{{- end -}}
