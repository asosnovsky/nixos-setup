{{ define "sibli.argoworkflow" }}
---
apiVersion: argoproj.io/v1alpha1
kind: WorkflowTemplate
metadata:
  name: "{{ .workflowName }}"
spec:
  arguments:
    parameters:
      {{- range .workflowParameters }}
      - name: {{ .name }}
        description: {{ .description }}
        {{- if .default }}
        value: {{ .default }}
        {{- end }}
      {{- end }}
  podMetadata:
    annotations:
      cluster-autoscaler.kubernetes.io/safe-to-evict: "false"
  serviceAccountName: {{ .serviceAccountName }}
  entrypoint: {{ .workflowEntrypoint | default "main" }}
  {{- if .credentials.containerRegistry }}
  imagePullSecrets:
    - name: {{ .credentials.containerRegistry.secretName }}
  {{- end }}
  templates:
    - name: {{ .workflowEntrypoint | default "main" }}

      {{- if .volumes }}
      volumes:
        {{- range $k, $v := .volumes }}
        - name: "{{ $k }}"
          {{- $v.from | toYaml | nindent 10 }}
        {{- end }}
      {{- end }}

      container:
        name: main
        image: "{{ `{{ workflow.parameters.mainContainerImageRepo }}` }}:{{ `{{ workflow.parameters.mainContainerImage }}` }}"
        imagePullPolicy: {{ .image.pullPolicy }}
        resources:
          {{- toYaml .resources | nindent 10 }}
        command:
          - {{ .cmd | default "/bin/sh" }}
        args:
          {{- if .args }}
          {{- range $_, $val := .args }}
          - {{ $val }}
          {{- end }}
          {{- else }}
          - "-c"
          - "/app/run.sh"
          {{- end }}
        {{- if .volumeMounts }}
        volumeMounts:
          {{- range $k, $v := .volumeMounts }}
          - name: "{{$k}}"
            mountPath: "{{$v.mountPath}}"
            {{- if $v.subPath }}
            subPath: "{{$v.subPath}}"
            {{- end }}
          {{- end }}
        {{- end }}
        env:
          {{- if .envsFromFieldPath }}
          {{- range $k, $v := .envsFromFieldPath }}
          - name: {{ $k | quote }}
            valueFrom:
              fieldRef:
                fieldPath: {{$v}}
          {{- end }}
          {{- end }}
          - name: WORKFLOW_SIDECAR_IMAGE
            value: "{{ `{{ workflow.parameters.sidecarImage }}` }}"
          - name: BACKEND_IMAGE
            value: "{{ `{{ workflow.parameters.backendImage }}` }}"
          - name: SIBLI_RAY_API_KEY
            value: "{{ `{{ workflow.parameters.ciJobToken }}` }}"
          - name: CI_MERGE_REQUEST_IID
            value: "{{ `{{ workflow.parameters.ciMergeRequestIid }}` }}"
          - name: CI_PROJECT_ID
            value: "{{ `{{ workflow.parameters.ciProjectId }}` }}"
        envFrom:
          - secretRef:
              name: ml-shared-secrets
          - secretRef:
              name: {{ .deployType }}-{{ .name }}-envs
          {{- if .envFrom }}
          {{- range $i, $val := .envFrom }}
          - secretRef:
              name: {{ $val }}
          {{- end }}
          {{- end }}

      sidecars:
        {{- range .sidecars }}
        - name: {{ .name }}
          {{- if eq .workflowImageKey "backend" }}
          image: "{{ `{{ workflow.parameters.backendImageRepo }}` }}:{{ `{{ workflow.parameters.backendImage }}` }}"
          {{- else }}
          image: "{{ `{{ workflow.parameters.sidecarImageRepo }}` }}:{{ `{{ workflow.parameters.sidecarImage }}` }}"
          {{- end }}
          imagePullPolicy: {{ .imagePullPolicy }}
          daemon: true
          wait: false
          resources:
            {{- toYaml .resources | nindent 12 }}
          {{- if .ports }}
          ports:
            {{- toYaml .ports | nindent 12 }}
          {{- end }}
          {{- if .args }}
          args:
            {{- range .args }}
            - {{ . }}
            {{- end }}
          {{- end }}
          {{- if .env }}
          env:
            {{- range $k, $v := .env }}
            - name: {{ $k | quote }}
              value: {{ $v | quote }}
            {{- end }}
          {{- end }}
          {{- if .secretRefs }}
          envFrom:
            {{- range .secretRefs }}
            - secretRef:
                name: {{ . }}
            {{- end }}
          {{- end }}
          {{- if .volumeMounts }}
          volumeMounts:
            {{- toYaml .volumeMounts | nindent 12 }}
          {{- end }}
        {{- end }}
{{ end }}