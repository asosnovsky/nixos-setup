

{{- define "sibli.labels" -}}
app.kubernetes.io/name: ray-{{ .name }}
app.kubernetes.io/type: ray-{{ .deployType }}
app.kubernetes.io/instance: ray-{{ .deployType }}
app.kubernetes.io/component: ray-{{ .component }}
{{- end }}
