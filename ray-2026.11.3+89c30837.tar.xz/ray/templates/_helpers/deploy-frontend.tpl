{{ define "sibli.deploy.frontend" }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ray-frontend
  labels:
    {{ include "sibli.labels" . | nindent 4 }}
spec:
{{ include "sibli.deploy.shared.spec" . }}
  template:
{{ include "sibli.deploy.shared.template" . }}
    spec:
{{ include "sibli.deploy.shared.template.spec" . }}
      containers:
        - name: frontend
{{ include "sibli.deploy.shared.container" . }}
          ports:
            - containerPort: 80
          {{- if .probes.enabled }}
          startupProbe:
            httpGet:
              port: 80
              path: /app/
            {{- .probes.startup | toYaml | nindent 12 }}
          livenessProbe:
            tcpSocket:
              port: 80
            {{- .probes.liveness | toYaml | nindent 12 }}
          readinessProbe:
            httpGet:
              port: 80
              path: /app/
            {{- .probes.readiness | toYaml | nindent 12 }}
          {{- end }}
---
kind: Service
apiVersion: v1
metadata:
  name: ray-frontend
  annotations:
    {{ range $k, $v := (.serviceAnnotations | default (dict)) }}
    "{{ $k }}": "{{ $v }}"
    {{ end }}
  labels:
    {{ range $k, $v := (.serviceLabels | default (dict)) }}
    "{{ $k }}": "{{ $v }}"
    {{ end }}
spec:
  selector:
    {{ include "sibli.labels" . | nindent 4 }}
  type: {{ .serviceType | default "ClusterIP" }}
  ports:
    - name: http
      port: 80
      targetPort: 80
{{ end }}
