{{ define "sibli.deploy.stream-worker-scaler" }}
{{ $target := printf "%s-%s" .deployType .name }}
---
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: {{ $target }}-scaler
spec:
  scaleTargetRef:
    kind: Deployment
    name: {{ $target }}
  {{ if $.globals.scaleToZero }}
  maxReplicaCount: 0
  minReplicaCount: 0
  {{ else }}
  minReplicaCount: {{ $.autoScaling.minReplicas | default 0 }}
  maxReplicaCount: {{ $.autoScaling.maxReplicas | default 1 }}
  {{ end }}
  pollingInterval: {{ $.autoScaling.pollingInterval | default 30 }}
  cooldownPeriod: {{ $.autoScaling.cooldownPeriod | default 300 }}
  triggers:
{{ range $subscriber := .streams.subscribers }}
    - type: redis-streams
      name: {{ $target }}-{{ $subscriber }}
      metadata:
        hostFromEnv: SIBLI_FS_SERVICE_HOST
        portFromEnv: SIBLI_FS_SERVICE_PORT
        {{ $streamName := (splitList ":" $subscriber | first) }}
        stream: {{ $.envs.SIBLI_FS_STREAM_PREFIX }}{{ $streamName }}
        consumerGroup: {{ $subscriber | replace ":" "-" }}-consumer-group
        pendingEntriesCount: "{{ $.envs.SIBLI_FS_BATCH_SIZE | default "500" }}"
        databaseIndex: "2"
        {{- if $.globals.redisStreamsTls }}
        enableTLS: "true"
        unsafeSsl: "true"
        {{- end }}
{{ end }}
{{ end }}
