{{ define "sibli.deploy.stream-worker" }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{.deployType}}-{{ .name }}
  labels:
    {{- include "sibli.labels" . | nindent 4 }}
spec:
{{ include "sibli.deploy.shared.spec" . }}
  template:
{{ include "sibli.deploy.shared.template" . }}
    spec:
{{ include "sibli.deploy.shared.template.spec" . }}
      containers:
        {{ include "sibli.sidecars" . | nindent 8}}
        - name: stream-worker
{{ include "sibli.deploy.shared.container" . }}
          {{ if .probes.enabled }}
          startupProbe:
            {{- .probes.startup | toYaml | nindent 12 }}
          readinessProbe:
            {{- .probes.readiness | toYaml | nindent 12 }}
          livenessProbe:
            {{- .probes.liveness | toYaml | nindent 12 }}
          {{ end }}
          env:
            - name: GUNICORN_WORKERS
              value: "{{ .gunicorn.workers }}"
            - name: GUNICORN_PORT
              value: "{{ .gunicorn.port }}"
            - name: GUNICORN_TIMEOUT
              value: "{{ .gunicorn.timeout }}"
            - name: GUNICORN_KEEPALIVE
              value: "{{ .gunicorn.keepalive }}"
            - name: GUNICORN_MAX_REQUESTS
              value: "{{ .gunicorn.max_requests }}"
            {{ if and .streams .streams.publishers }}
            - name: SIBLI_FS_enabled_publishers
              value: |-
                {{ .streams.publishers | toJson }}
            {{ end }}
            {{ if and .streams .streams.subscribers }}
            - name: SIBLI_FS_enabled_subscribers
              value: |-
                {{ .streams.subscribers | toJson }}
            {{ end }}
            {{ include "sibli.shared.envs" . | nindent 12 }}
---
apiVersion: v1
kind: Service
metadata:
  name: {{ .deployType }}-{{ .name }}
  labels:
    {{- include "sibli.labels" . | nindent 4 }}
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/port: "{{ .gunicorn.port }}"
    prometheus.io/path: "/metrics"
spec:
  type: ClusterIP
  selector:
    {{- include "sibli.labels" . | nindent 4 }}
  ports:
    - name: http
      port: 80
      targetPort: {{ .gunicorn.port }}
---
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: {{ .deployType }}-{{ .name }}
  labels:
    release: kube-prometheus-stack
spec:
  selector:
    matchLabels:
      {{- include "sibli.labels" . | nindent 6 }}
  endpoints:
    - port: http
      path: /metrics
      interval: 30s
{{ end }}
