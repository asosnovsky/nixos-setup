{{- /* Scrapes the Procrastinate dashboard's /metrics on whichever service serves it
  (`devTooling.source`, see dev-tooling.tpl). Takes a dict with `devTooling` and
  `mainStack`. */ -}}
{{ define "sibli.deploy.monitor.procrastinate" }}
{{- $target := include "sibli.devTooling.procrastinateTarget" . | fromJson }}
---
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: procrastinate
  labels:
    release: kube-prometheus-stack
spec:
  selector:
    matchLabels:
      {{ include "sibli.labels" (dict
        "name" $target.name
        "deployType" "endpoint"
        "component" "ml"
      ) | nindent 6}}
  endpoints:
    - port: http
      path: {{ $target.basePath }}/metrics
      interval: 30s
{{ end }}
