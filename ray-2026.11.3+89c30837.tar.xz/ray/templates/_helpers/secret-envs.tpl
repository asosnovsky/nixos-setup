{{ define "sibli.envs" }}
---
apiVersion: v1
kind: Secret
type: Opaque
metadata:
  name: {{.deployType}}-{{.name}}-envs
  annotations:
    {{ range $key, $val := .envAnnotations }}
        {{ $key }}: "{{ $val }}"
    {{ end }}
stringData:
  POSTGRES_application_name: "Sibli {{.deployType}}-{{.name}}"
  {{- range $k, $v := ( .envs | default (dict "_placeholder" "")) }}
  {{$k}}: |-
    {{$v}}
  {{- end }}
{{ end }}
