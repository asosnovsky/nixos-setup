{{/*
    The target half of an endpoint probe (httpGet/tcpSocket), kept in one place so
    the startup, liveness and readiness probes cannot drift apart. Timings come
    from .probes in values; only the target is derived here.
*/}}
{{ define "sibli.endpoint.probeTarget" }}
{{- if .mcpMode }}
tcpSocket:
  port: {{ .gunicorn.port }}
{{- else }}
httpGet:
  path: {{ .gunicorn.healthcheckPath | default "/" }}
  port: {{ .gunicorn.port }}
{{- end }}
{{- end }}

{{ define "sibli.deploy.endpoint" }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ray-{{.deployType}}-{{ .name }}
  labels:
    {{- include "sibli.labels" . | nindent 4 }}
spec:
{{ include "sibli.deploy.shared.spec" . }}
  template:
{{ include "sibli.deploy.shared.template" . }}
    spec:
{{ include "sibli.deploy.shared.template.spec" . }}
      containers:
        {{ include "sibli.sidecars" . | nindent 8}}
        - name: api
{{ include "sibli.deploy.shared.container" . }}
          {{- if .probes.enabled }}
          startupProbe:
            {{- include "sibli.endpoint.probeTarget" . | trim | nindent 12 }}
            {{- .probes.startup | toYaml | nindent 12 }}
          livenessProbe:
            {{- include "sibli.endpoint.probeTarget" . | trim | nindent 12 }}
            {{- .probes.liveness | toYaml | nindent 12 }}
          readinessProbe:
            {{- include "sibli.endpoint.probeTarget" . | trim | nindent 12 }}
            {{- .probes.readiness | toYaml | nindent 12 }}
          {{- end }}
          env:
{{- if .mcpMode }}
            - name: SIBLI_MCP_module_name
              value: "{{ .moduleName }}"
{{- if .mcpAuth.enabled }}
            - name: SIBLI_CONFIG_AUTH__MCP__ENABLED
              value: "{{ .mcpAuth.enabled }}"
            - name: SIBLI_CONFIG_AUTH__MCP__ISSUER_URL
              value: "{{ .mcpAuth.publicOrigin }}/"
            - name: SIBLI_CONFIG_AUTH__MCP__RESOURCE_URL
              value: "{{ .mcpAuth.resourceOrigin }}"
            - name: SIBLI_CONFIG_AUTH__MCP__HYDRA_PUBLIC_URL
              value: "http://ray-hydra:4444"
{{- end }}
{{- else }}
            - name: SIBLI_API_module_name
              value: "{{ .moduleName }}"
{{- end }}
{{- /*
  rocketcar serves login/consent + DCR and mints run tokens at /handle, so it
  needs both Hydra URLs.
*/ -}}
{{- if and .mcpAuth.enabled (eq .moduleName "rocketcar") }}
            - name: SIBLI_CONFIG_AUTH__MCP__ENABLED
              value: "{{ .mcpAuth.enabled }}"
            - name: SIBLI_CONFIG_AUTH__MCP__ISSUER_URL
              value: "{{ .mcpAuth.publicOrigin }}/"
            - name: SIBLI_CONFIG_AUTH__MCP__RESOURCE_URL
              value: "{{ .mcpAuth.resourceOrigin }}"
            - name: SIBLI_CONFIG_AUTH__MCP__HYDRA_PUBLIC_URL
              value: "http://ray-hydra:4444"
            - name: SIBLI_CONFIG_AUTH__MCP__HYDRA_ADMIN_URL
              value: "http://ray-hydra-admin:4445"
{{- if .harness.enabled }}
{{- /* Must match the worker: both upsert the same per-run Hydra client. */}}
            - name: SIBLI_CONFIG_HARNESS__MCP_SCOPES
              value: |-
                {{ .harness.mcp.scopes | toJson }}
{{- end }}
{{- end }}
{{- if .rayServeMode }}
            - name: SIBLI_SERVE_module_name
              value: "{{ .rayServeModuleName | default .moduleName }}"
{{- end }}
            - name: GUNICORN_WORKERS
              value: "{{ .gunicorn.workers }}"
            - name: GUNICORN_PORT
              value: "{{ .gunicorn.port }}"
            - name: GUNICORN_TIMEOUT
              value: "{{ .gunicorn.timeout }}"
            - name: GUNICORN_KEEPALIVE
              value: "{{ .gunicorn.keepalive }}"
            - name: GUNICORN_MAX_REQUESTS
              value: "{{ .gunicorn.max_requests }}"
            {{ include "sibli.shared.envs" . | nindent 12 }}
{{ if .service.enabled }}
---
kind: Service
apiVersion: v1
metadata:
  name: "ray-api-{{ .name }}"
  annotations:
    {{- $ann := deepCopy .service.annotations }}
    {{- $bc := .backendConfig }}
    {{- if and $bc $bc.enabled (has .name (default (list) $bc.services)) }}
    {{- $_ := set $ann "cloud.google.com/backend-config" (printf "{\"default\":\"%s\"}" $bc.name) }}
    {{- end }}
    {{ $ann | toYaml | nindent 4  }}
  {{- /* The workload's own labels, so a ServiceMonitor selecting `sibli.labels` (the
    Procrastinate monitor) finds this Service. `.service.labels` can add or override. */}}
  {{- $svcLabels := mergeOverwrite (include "sibli.labels" . | fromYaml) (deepCopy (.service.labels | default dict)) }}
  labels:
    {{- $svcLabels | toYaml | nindent 4 }}
spec:
  selector:
    {{- include "sibli.labels" . | nindent 4 }}
  type: {{ .service.type }}
  ports:
    - name: http
      port: 80
      targetPort: {{ .gunicorn.port }}
{{ end }}
{{ end }}
