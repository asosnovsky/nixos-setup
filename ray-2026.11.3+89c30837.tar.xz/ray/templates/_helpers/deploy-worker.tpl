{{ define "sibli.deploy.worker" }}
{{- if and .procrastinate.enabled .celery.enabled }}
  {{-
      fail (
        printf
        "Error: Both `procrastinate.enabled` and `celery.enabled` are enabled for 'worker-%s' cannot be true simultaneously. Only one must be enabled."
        .name
      )
  }}
{{- end }}
{{- if and (not .procrastinate.enabled) (not .celery.enabled) }}
  {{-
    fail (
      printf
      "Error: Either `procrastinate.enabled` or `celery.enabled` must be enabled for 'worker-%s' cannot be false simultaneously. One must be enabled."
      .name
    )
  }}
{{- end }}
{{ $enabled_worker_modules := list }}
{{ range $component, $componentStatus := .components }}
  {{ if $componentStatus }}
  {{ $enabled_worker_modules = append $enabled_worker_modules $component }}
  {{ end }}
{{ end }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: "ray-{{ .celery.mode | default .deployType }}-{{ .name }}"
  labels:
    {{- include "sibli.labels" . | nindent 4 }}
spec:
{{ include "sibli.deploy.shared.spec" . }}
  template:
{{ include "sibli.deploy.shared.template" . }}
    spec:
{{ include "sibli.deploy.shared.template.spec" . }}
      containers:
        {{ include "sibli.sidecars" . | nindent 8}}
        - name: worker
{{ include "sibli.deploy.shared.container" . }}
          {{ if .probes.enabled }}
            {{ if (and (eq .celery.mode "flower") .celery.enabled) }}
          startupProbe:
            httpGet:
              port: 5555
              path: /{{ .celery.flower.urlPrefix }}/healthcheck
            timeoutSeconds: {{ .probes.startup.timeoutSeconds }}
            periodSeconds: {{ .probes.startup.periodSeconds }}
            successThreshold: {{ .probes.startup.successThreshold }}
            failureThreshold: {{ .probes.startup.failureThreshold }}
          livenessProbe:
            httpGet:
              port: 5555
              path: /{{ .celery.flower.urlPrefix }}/healthcheck
            timeoutSeconds: {{ .probes.liveness.timeoutSeconds }}
            periodSeconds: {{ .probes.liveness.periodSeconds }}
            successThreshold: {{ .probes.liveness.successThreshold }}
            failureThreshold: {{ .probes.liveness.failureThreshold }}
          readinessProbe:
            httpGet:
              port: 5555
              path: /{{ .celery.flower.urlPrefix }}/healthcheck
            timeoutSeconds: {{ .probes.readiness.timeoutSeconds }}
            periodSeconds: {{ .probes.readiness.periodSeconds }}
            successThreshold: {{ .probes.readiness.successThreshold }}
            failureThreshold: {{ .probes.readiness.failureThreshold }}
            {{ else }}
          {{- /* The startup probe runs the READY check: for a worker, "started"
                 means it has written its readiness file and can take work. */}}
          startupProbe:
            exec:
              command:
                - /ray/bin/probe
                {{ if .celery.enabled }}
                - celery-ready
                {{ end }}
                {{ if .procrastinate.enabled }}
                - worker-ready
                {{ end }}
            timeoutSeconds: {{ .probes.startup.timeoutSeconds }}
            periodSeconds: {{ .probes.startup.periodSeconds }}
            successThreshold: {{ .probes.startup.successThreshold }}
            failureThreshold: {{ .probes.startup.failureThreshold }}
          readinessProbe:
            exec:
              command:
                - /ray/bin/probe
                {{ if .celery.enabled }}
                - celery-ready
                {{ end }}
                {{ if .procrastinate.enabled }}
                - worker-ready
                {{ end }}
            timeoutSeconds: {{ .probes.readiness.timeoutSeconds }}
            periodSeconds: {{ .probes.readiness.periodSeconds }}
            successThreshold: {{ .probes.readiness.successThreshold }}
            failureThreshold: {{ .probes.readiness.failureThreshold }}
          livenessProbe:
            exec:
              command:
                - /ray/bin/probe
                {{ if .celery.enabled }}
                - celery-liveness
                {{ end }}
                {{ if .procrastinate.enabled }}
                - worker-liveness
                {{ end }}
            timeoutSeconds: {{ .probes.liveness.timeoutSeconds }}
            periodSeconds: {{ .probes.liveness.periodSeconds }}
            successThreshold: {{ .probes.liveness.successThreshold }}
            failureThreshold: {{ .probes.liveness.failureThreshold }}
            {{ end }}
          {{ end }}
          env:
            {{ if .celery.enabled }}
            {{ include "sibli.deploy.worker.celery.envs" . }}
            {{ end }}
            {{ if .procrastinate.enabled }}
            {{ include "sibli.deploy.worker.procrastinate.envs" . }}
            {{ end }}

            {{ if and .streams .streams.publishers }}
            - name: SIBLI_FS_enabled_publishers
              value: |-
                {{ .streams.publishers | toJson }}
            {{ end }}
            {{ if and .streams .streams.subscribers }}
            - name: SIBLI_FS_enabled_subscribers
              value: |-
                {{ .streams.subscribers | toJson }}
            {{ end }}
            {{ include "sibli.shared.envs" . | nindent 12 }}
{{- /*
  Harness only: the worker mints each run's MCP token (per-run Hydra client via
  the admin API). Not in sibli.shared.envs, where endpoint and mcp would
  duplicate it.
*/}}
{{- if and .harness.enabled .mcpAuth.enabled }}
            - name: SIBLI_CONFIG_AUTH__MCP__ENABLED
              value: "{{ .mcpAuth.enabled }}"
            - name: SIBLI_CONFIG_AUTH__MCP__ISSUER_URL
              value: "{{ .mcpAuth.publicOrigin }}/"
            - name: SIBLI_CONFIG_AUTH__MCP__RESOURCE_URL
              value: "{{ .mcpAuth.resourceOrigin }}"
            - name: SIBLI_CONFIG_AUTH__MCP__HYDRA_PUBLIC_URL
              value: "http://ray-hydra:4444"
            - name: SIBLI_CONFIG_AUTH__MCP__HYDRA_ADMIN_URL
              value: "http://ray-hydra-admin:4445"
{{- /* Requested scopes; must cover mcpAuth.requiredScopes (what the server enforces). */}}
            - name: SIBLI_CONFIG_HARNESS__MCP_SCOPES
              value: |-
                {{ .harness.mcp.scopes | toJson }}
{{- end }}

  {{ if (and (eq .celery.mode "flower") .celery.enabled) }}
    {{ include "sibli.deploy.worker.celery.flower" . }}
  {{ end }}

{{ end }}


#
# Procrastinate Configuration Variables
#
{{ define "sibli.deploy.worker.procrastinate.envs"}}
            - name: SIBLI_WORKER_worker_mode
              value: procrastinate
            - name: SIBLI_PROCRASTINATE_TARGET_QUEUES
              value: |-
                {{ .procrastinate.targetQueues | toJson }}
            - name: SIBLI_PROCRASTINATE_WORKER_CONCURRENCY
              value: "{{ .procrastinate.concurrency }}"
            - name: SIBLI_PROCRASTINATE_heartbeat_interval
              value: "{{ .procrastinate.heartbeat_interval }}"
{{ end }}

#
# Celery Configuration Variables
#
{{ define "sibli.deploy.worker.celery.envs"}}
            - name: SIBLI_WORKER_worker_mode
              value: celery
            - name: CELERY_TARGET_QUEUES
              value: |-
                {{ .celery.targetQueues | toJson }}
            - name: CELERY_sibli_worker_run_mode
              value: "{{ .celery.mode }}"
            - name: CELERY_WORKER_POOL
              value: "{{ .celery.pool }}"
            - name: CELERY_WORKER_CONCURRENCY
              value: "{{ .celery.concurrency }}"
            - name: CELERY_LOCK_REFRESH_RATE
              value: "{{ .celery.lock_refresh_rate }}"
        {{ if (eq .celery.mode "flower") }}
            - name: FLOWER_URL_PREFIX
              value: "{{ .celery.flower.urlPrefix }}"
            - name: FLOWER_BASIC_AUTH
              value: "{{ .celery.flower.basicAuth.username }}:{{ .celery.flower.basicAuth.password }}"
        {{ end }}
{{ end }}

#
# Celery Flower K8s Services
#
{{ define "sibli.deploy.worker.celery.flower" }}
---
apiVersion: v1
kind: Service
metadata:
  name: ray-{{ .celery.mode | default .deployType }}-{{ .name }}
  annotations:
    {{ .celery.flower.serviceAnnotations | default (dict) | toYaml | indent 4 }}
  labels:
    {{- include "sibli.labels" . | nindent 4 }}
    {{ range $k, $v := (.celery.flower.serviceLabels | default (dict)) }}
    "{{ $k }}": "{{ $v }}"
    {{ end }}
spec:
  type: {{ .celery.flower.serviceType | default "ClusterIP" }}
  ports:
    -   name: http
        port: 5555
        protocol: TCP
        targetPort: 5555
  selector:
    {{- include "sibli.labels" . | nindent 4 }}

{{- if .celery.flower.enablePrometheus }}
---
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: ray-celery-flower
  labels:
    release: kube-prometheus-stack
spec:
  selector:
    matchLabels:
      app.kubernetes.io/instance: flower
      app.kubernetes.io/name: flower
  endpoints:
    - port: http
      path: /{{ .celery.flower.urlPrefix }}/metrics
      interval: 30s
{{- end }}
{{ end }}
