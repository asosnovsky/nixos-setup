{{ define "sibli.deploy.mcp" }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ray-{{.deployType}}-{{ .name }}
  labels:
    {{- include "sibli.labels" . | nindent 4 }}
spec:
{{ include "sibli.deploy.shared.spec" . }}
  template:
{{ include "sibli.deploy.shared.template" . }}
    spec:
{{ include "sibli.deploy.shared.template.spec" . }}
      containers:
        {{ include "sibli.sidecars" . | nindent 8}}
        - name: api
{{ include "sibli.deploy.shared.container" . }}
          {{- /* Target (httpGet against .gunicorn.healthcheckPath, default "/")
                 comes from sibli.endpoint.probeTarget in deploy-endpoint.tpl --
                 kept in one place so mcp and endpoint probes can't drift apart.
                 Only timings live here; see mainStack.defaults.mcps. */}}
          {{- if .probes.enabled }}
          startupProbe:
            {{- include "sibli.endpoint.probeTarget" . | trim | nindent 12 }}
            {{- .probes.startup | toYaml | nindent 12 }}
          livenessProbe:
            {{- include "sibli.endpoint.probeTarget" . | trim | nindent 12 }}
            {{- .probes.liveness | toYaml | nindent 12 }}
          readinessProbe:
            {{- include "sibli.endpoint.probeTarget" . | trim | nindent 12 }}
            {{- .probes.readiness | toYaml | nindent 12 }}
          {{- end }}
          env:
            - name: SIBLI_MCP_module_name
              value: "{{ .moduleName }}"
{{/* The MCP resource server. Without this it keeps enforcing
  X-SIBLI-API-KEY and never emits the 401 + PRM the OAuth flow starts from. */}}
{{- if .mcpAuth.enabled }}
            - name: SIBLI_CONFIG_AUTH__MCP__ENABLED
              value: "{{ .mcpAuth.enabled }}"
            - name: SIBLI_CONFIG_AUTH__MCP__ISSUER_URL
              value: "{{ .mcpAuth.publicOrigin }}/"
            - name: SIBLI_CONFIG_AUTH__MCP__RESOURCE_URL
              value: "{{ .mcpAuth.resourceOrigin }}"
{{- /* Scopes every caller must carry; the harness requests harness.mcp.scopes. */}}
            - name: SIBLI_CONFIG_AUTH__MCP__REQUIRED_SCOPES
              value: |-
                {{ .mcpAuth.requiredScopes | toJson }}
            - name: SIBLI_CONFIG_AUTH__MCP__HYDRA_PUBLIC_URL
              value: "http://ray-hydra:4444"
{{- end }}
            - name: GUNICORN_WORKERS
              value: "{{ .gunicorn.workers }}"
            - name: GUNICORN_PORT
              value: "{{ .gunicorn.port }}"
            - name: GUNICORN_TIMEOUT
              value: "{{ .gunicorn.timeout }}"
            - name: GUNICORN_KEEPALIVE
              value: "{{ .gunicorn.keepalive }}"
            - name: GUNICORN_MAX_REQUESTS
              value: "{{ .gunicorn.max_requests }}"
            {{ include "sibli.shared.envs" . | nindent 12 }}
{{ if .service.enabled }}
---
kind: Service
apiVersion: v1
metadata:
  name: "ray-mcp-{{ .name }}"
  annotations:
    {{- $ann := deepCopy .service.annotations }}
    {{- $bc := .backendConfig }}
    {{- if and $bc $bc.enabled (has .name (default (list) $bc.services)) }}
    {{- $_ := set $ann "cloud.google.com/backend-config" (printf "{\"default\":\"%s\"}" $bc.name) }}
    {{- end }}
    {{ $ann | toYaml | nindent 4  }}
  labels:
    {{ .service.labels | toYaml | nindent 4 }}
spec:
  selector:
    {{- include "sibli.labels" . | nindent 4 }}
  type: {{ .service.type }}
  ports:
    - name: http
      port: 80
      targetPort: {{ .gunicorn.port }}
{{ end }}
{{ end }}
