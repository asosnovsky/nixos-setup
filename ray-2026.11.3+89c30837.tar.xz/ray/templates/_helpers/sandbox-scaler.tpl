{{/*
  KEDA scaler for an executor pool: one pod per unfinished run (waiting, or
  still holding its pod). minReplicas >= 1 keeps the pool warm.
*/}}
{{ define "sibli.deploy.sandbox-scaler" }}
{{- $target := printf "ray-%s-%s" .deployType .name -}}
---
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: {{ $target }}-scaler
  labels:
    {{- include "sibli.labels" . | nindent 4 }}
spec:
  scaleTargetRef:
    kind: Deployment
    name: {{ $target }}
  minReplicaCount: {{ .autoScaling.minReplicas }}
  maxReplicaCount: {{ .autoScaling.maxReplicas }}
  pollingInterval: {{ .autoScaling.pollingInterval | default 10 }}
  cooldownPeriod: {{ .autoScaling.cooldownPeriod | default 300 }}
  advanced:
    horizontalPodAutoscalerConfig:
      behavior:
        scaleDown:
          {{- /* Slow: a pod may be mid-run, and runs can be long. */}}
          stabilizationWindowSeconds: 600
          policies:
            - type: Pods
              value: 1
              periodSeconds: 120
        scaleUp:
          stabilizationWindowSeconds: 0
          policies:
            - type: Pods
              value: {{ .autoScaling.scaleUpPodsPerInterval | default 2 }}
              periodSeconds: 30
  triggers:
    - type: metrics-api
      metadata:
        {{- /* Per pool, so one pool's queue does not scale the others. */}}
        url: "{{ include "sibli.sandbox.apiUrl" . }}/keda?runtime={{ .runtimeName | default .name }}"
        valueLocation: "unfinished"
        targetValue: "1"
        activationTargetValue: "0"
        format: "json"
{{ end }}
