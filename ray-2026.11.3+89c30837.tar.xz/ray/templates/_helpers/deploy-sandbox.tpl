{{/*
  Warm executor pool for the agent harness. Replicas belong to the KEDA
  ScaledObject (sandbox-scaler.tpl); the app deletes each pod after its run.

  Runs model-generated code, so it is written out by hand: the shared
  sibli.deploy.shared.* helpers attach ml-shared-secrets. Inherited envFrom,
  volumes, initContainers, sideCars and annotations are ignored -- use
  podAnnotations.

  The pool serves runtime `runtimeName`, defaulting to its key.
*/}}
{{ define "sibli.deploy.sandbox" }}
{{- if .autoScaling.enabled | default false }}
{{- fail (printf "Error: set replicas via the ScaledObject, not autoScaling, for '%s-%s'" .deployType .name) }}
{{- end }}
{{- /* The agent is told workspaceDirectory; a mismatch silently loses its outputs. */}}
{{- if ne .harness.workspaceDirectory .workspace.mountPath }}
{{- fail (printf "Error: harness.workspaceDirectory (%s) must equal mainStack.defaults.sandboxes.workspace.mountPath (%s)" .harness.workspaceDirectory .workspace.mountPath) }}
{{- end }}
{{- $runtime := (.runtimeName | default .name) }}
{{- if not (hasKey .harness.runtimes $runtime) }}
{{- fail (printf "Error: sandbox pool '%s' serves runtime '%s', which has no harness.runtimes entry -- no run could ever be routed to it. Add 'harness.runtimes.%s' (a list of allowed MCP tools, [] for all), or set runtimeName on the pool." .name $runtime $runtime) }}
{{- end }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ray-{{ .deployType }}-{{ .name }}
  labels:
    {{- include "sibli.labels" . | nindent 4 }}
spec:
{{ include "sibli.deploy.shared.spec" . }}
  template:
    metadata:
      labels:
        {{- include "sibli.labels" . | nindent 8 }}
      annotations:
        {{- /* Roll the pool when its claim URL or secret changes. */}}
        sibli-checksums/sandbox: "{{ (dict "apiUrl" (include "sibli.sandbox.apiUrl" .) "secret" .sandboxSecretName) | toJson | sha256sum }}"
        {{- range $key, $value := (.podAnnotations | default (dict)) }}
        {{ $key }}: "{{ $value }}"
        {{- end }}
    spec:
      {{- /* Hook for a sandboxing runtime (e.g. gVisor); unset today. */}}
      {{- if .runtimeClassName }}
      runtimeClassName: {{ .runtimeClassName }}
      {{- end }}
      {{- include "sibli.deploy.shared.template.spec.nodeSelectors" . }}
      {{- /* Untrusted code gets no API-server token. */}}
      automountServiceAccountToken: false
      terminationGracePeriodSeconds: {{ .terminationGracePeriodSeconds | default 30 }}
      securityContext:
        runAsNonRoot: true
        runAsUser: {{ .security.runAsUser | default 1000 }}
        runAsGroup: {{ .security.runAsGroup | default 1000 }}
        fsGroup: {{ .security.fsGroup | default 1000 }}
        seccompProfile:
          type: RuntimeDefault
      {{- /* Terraform-supplied; absent in some environments. */}}
      {{ if .credentials.containerRegistry }}
      imagePullSecrets:
        - name: {{ .credentials.containerRegistry.secretName }}
      {{ else if .imagePullSecrets }}
      imagePullSecrets:
        {{ .imagePullSecrets | toYaml | nindent 9 }}
      {{ end }}
      volumes:
        - name: workspace
          emptyDir:
            sizeLimit: {{ .workspace.sizeLimit }}
        - name: tmp
          emptyDir:
            sizeLimit: 512Mi
      containers:
        - name: executor
          image: "{{ .image.repo }}:{{ .image.tag }}"
          imagePullPolicy: {{ .image.pullPolicy | default "IfNotPresent" }}
          {{- /* No probes: the supervisor listens on nothing. */}}
          {{- /* Read-only root: the agent runs as the supervisor and must not rewrite its helpers. */}}
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: true
            capabilities:
              drop: ["ALL"]
          volumeMounts:
            - name: workspace
              mountPath: {{ .workspace.mountPath }}
            - name: tmp
              mountPath: /tmp
          {{- /* The pod's only secret: CODEX_API_KEY and the claim token. */}}
          envFrom:
            - secretRef:
                name: {{ .sandboxSecretName }}
          env:
            - name: SIBLI_HARNESS_API_URL
              value: "{{ include "sibli.sandbox.apiUrl" . }}"
            - name: SIBLI_HARNESS_WORKSPACE
              value: "{{ .workspace.mountPath }}"
            - name: SIBLI_HARNESS_POD_NAME
              valueFrom:
                fieldRef:
                  fieldPath: metadata.name
            - name: SIBLI_HARNESS_RUNTIME
              value: "{{ .runtimeName | default .name }}"
          resources:
            {{- .resources | toYaml | nindent 12 }}
{{ end }}

{{/* Runner API base URL; `.api.url` overrides the in-cluster default. */}}
{{- define "sibli.sandbox.apiUrl" -}}
{{- if .api.url -}}
{{ .api.url }}
{{- else -}}
http://ray-api-{{ .api.serviceName }}.{{ .Release.Namespace }}.svc.cluster.local{{ .api.path }}
{{- end -}}
{{- end -}}
