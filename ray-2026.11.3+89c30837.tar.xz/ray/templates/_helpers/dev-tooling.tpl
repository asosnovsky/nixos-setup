{{- /*
  Where the engineer tooling (dev portal, Procrastinate dashboard) is served.

  `devTooling.source`:
    rocketcar   -- rocketcar serves /dev/portal and /dev/jobs behind its super-user
                   check. The standalone `dev_portal` and `procrastinate_dashboard`
                   endpoints are not rendered; KEDA and the ServiceMonitor point at
                   rocketcar. Needs an app image with sr-ai/ray/app!3019.
    standalone  -- the unauthenticated `ray-api-dev-portal` and
                   `ray-api-procrastinate-dashboard` services, as before. For stacks
                   without rocketcar (ray-data, ray-data-dev).

  Every helper takes a dict with `devTooling` and `mainStack` (the chart values, or a
  workload state built from them).
*/ -}}

{{- define "sibli.devTooling.standalone" -}}
{{- $source := (.devTooling | default dict).source | default "rocketcar" -}}
{{- if not (has $source (list "rocketcar" "standalone")) -}}
{{- fail (printf "devTooling.source must be 'rocketcar' or 'standalone', got %q" $source) -}}
{{- end -}}
{{- if eq $source "standalone" -}}true{{- end -}}
{{- end }}

{{- /* The Service + base path the Procrastinate dashboard's KEDA count and metrics live at. */ -}}
{{- define "sibli.devTooling.procrastinateTarget" -}}
{{- if eq (include "sibli.devTooling.standalone" .) "true" -}}
{{- if not .mainStack.endpoints.procrastinate_dashboard.enabled -}}
{{- fail "devTooling.source=standalone needs mainStack.endpoints.procrastinate_dashboard.enabled for Procrastinate autoscaling and metrics" -}}
{{- end -}}
{{- dict "name" "procrastinate-dashboard" "basePath" "/procrastinate-dashboard" | toJson -}}
{{- else -}}
{{- if not .mainStack.endpoints.rocketcar.enabled -}}
{{- fail "devTooling.source=rocketcar needs mainStack.endpoints.rocketcar.enabled; set devTooling.source=standalone on stacks without rocketcar" -}}
{{- end -}}
{{- dict "name" "rocketcar" "basePath" "/dev/jobs" | toJson -}}
{{- end -}}
{{- end }}
