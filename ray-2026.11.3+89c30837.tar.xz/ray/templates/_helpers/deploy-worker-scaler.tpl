{{ define "sibli.deploy.worker-scaler" }}
{{ $_ := (set $ "target" (printf "ray-%s-%s" .deployType .name)) }}
{{ if $.celery.enabled }}
{{ include "sibli.deploy.worker-scaler.celery" . }}
{{ end }}
{{ if $.procrastinate.enabled }}
{{ include "sibli.deploy.worker-scaler.procrastinate" . }}
{{ end }}
{{ end }}


{{ define "sibli.deploy.worker-scaler.shared" }}
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: {{ .target }}-scaler
spec:
  scaleTargetRef:
    kind: Deployment
    name: {{ .target }}
  {{ if $.globals.scaleToZero }}
  maxReplicaCount: 0
  minReplicaCount: 0
  {{ else }}
  minReplicaCount: {{ $.autoScaling.minReplicas | default 0 }}
  maxReplicaCount: {{ $.autoScaling.maxReplicas | default 1 }}
  {{ end }}
  pollingInterval: {{ $.autoScaling.pollingInterval | default 30 }}
  cooldownPeriod: {{ $.autoScaling.cooldownPeriod | default 300 }}
{{ end }}

{{ define "sibli.deploy.worker-scaler.celery" }}
---
  {{ include "sibli.deploy.worker-scaler.shared" . }}
  triggers:
{{ range $queue := .celery.targetQueues }}
    - type: redis
      name: "worker_{{ $queue }}"
      metadata:
        hostFromEnv: CACHE_SERVICE_HOST
        portFromEnv: CACHE_SERVICE_PORT
        listName: {{ $queue }}
        listLength: "{{ $.celery.concurrency }}"
        databaseIndex: "0"
{{ end }}
{{ end }}


{{ define "sibli.deploy.worker-scaler.procrastinate" }}
{{- /* The KEDA count lives on whichever service serves the dashboard: the standalone
  `procrastinate-dashboard` endpoint, or rocketcar at /dev/jobs (see dev-tooling.tpl,
  which also fails the render when that service is not enabled). */ -}}
{{- $kedaTarget := include "sibli.devTooling.procrastinateTarget" . | fromJson -}}

{{- $concurrency := .procrastinate.concurrency -}}
{{- $baseUrl := printf "http://ray-api-%s.%s.svc.cluster.local%s/api/keda" $kedaTarget.name .Release.Namespace $kedaTarget.basePath -}}

{{- /* Build ?queues=a&queues=b&status=todo&status=doing */ -}}
{{- $params := list -}}
{{- range $q := .procrastinate.targetQueues -}}
  {{- $params = append $params (printf "queues=%s" $q) -}}
{{- end -}}
{{- range $s := list "todo" "doing" "aborting" -}}
  {{- $params = append $params (printf "status=%s" $s) -}}
{{- end -}}
{{- $url := printf "%s?%s" $baseUrl (join "&" $params) -}}

---
{{ include "sibli.deploy.worker-scaler.shared" . }}
  advanced:
    horizontalPodAutoscalerConfig:
      behavior:
        scaleDown:
          # Scale down cautiously; procrastinate workers may be mid-job.
          stabilizationWindowSeconds: 300
          policies:
            - type: Percent
              value: 50
              periodSeconds: 60
        scaleUp:
          stabilizationWindowSeconds: 0
          policies:
            - type: Percent
              value: 100
              periodSeconds: 30
            - type: Pods
              value: 4
              periodSeconds: 30
          selectPolicy: Max
  triggers:
    - type: metrics-api
      metadata:
        url: {{ $url | quote }}
        valueLocation: "count"
        targetValue: {{ $concurrency | quote }}
        # activationTargetValue controls scale-from-zero. With minReplicaCount=0,
        # KEDA stays at 0 until count > this number.
        activationTargetValue: "0"
        format: "json"
{{ end }}
