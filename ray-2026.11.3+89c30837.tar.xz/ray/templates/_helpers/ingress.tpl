{{ define "sibli.ingress" }}
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{.ingressName}}
  annotations:
    {{ .annotations | toYaml | nindent 4 }}
  labels:
    {{ (.labels | default dict) | toYaml | nindent 4 }}
spec:
  {{ if .ingressClassName }}
  ingressClassName: {{ .ingressClassName }}
  {{ end }}
  {{ if .tls }}
  tls:
    {{ .tls | toYaml | nindent 4 }}
  {{ end }}
  rules:
    {{ if (not (eq .host "*")) }}
    - host: "{{.host}}"
      http:
    {{ else }}
    - http:
    {{ end }}
        paths:
{{- /* Private Routes: Admin tools and internal services (not for public internet) */ -}}
{{- /* Admin Tools */ -}}
{{ if (and .Values.tools.insights.enabled .enabledRoutes.redisinsights) }}
          - path: "/{{ .Values.tools.insights.urlPrefix }}"
            pathType: Prefix
            backend:
              service:
                name: redis-insights
                port:
                  number: 80
{{ end }}
{{ if (and .Values.tools.rediscommander.enabled .enabledRoutes.rediscommander) }}
          - path: "/{{ .Values.tools.rediscommander.urlPrefix }}"
            pathType: Prefix
            backend:
              service:
                name: ray-rediscommander
                port:
                  number: 80
{{ end }}
{{ if (and .Values.tools.flower.enabled .enabledRoutes.flower) }}
          - path: "/{{ .Values.tools.flower.urlPrefix }}"
            pathType: Prefix
            backend:
              service:
                name: ray-celery-flower
                port:
                  number: 5555
{{ end }}
{{- /* Standalone, unauthenticated dev tooling: only with devTooling.source=standalone.
  Otherwise rocketcar serves both under /dev (below). */ -}}
{{ $devToolingStandalone := eq (include "sibli.devTooling.standalone" .Values) "true" }}
{{ if (and $devToolingStandalone .Values.mainStack.endpoints.procrastinate_dashboard.enabled .enabledRoutes.procrastinateDashboard) }}
          - path: "/procrastinate-dashboard"
            pathType: Prefix
            backend:
              service:
                name: ray-api-procrastinate-dashboard
                port:
                  number: 80
{{ end }}
{{ if (and .Values.mainStack.workers.monitor.enabled .enabledRoutes.flowerMonitorWorker) }}
          - path: "/{{ .Values.mainStack.defaults.workers.celery.flower.urlPrefix }}"
            pathType: Prefix
            backend:
              service:
                name: ray-flower-monitor
                port:
                  number: 5555
{{ end }}
{{ if (and $devToolingStandalone .Values.mainStack.endpoints.dev_portal.enabled .enabledRoutes.dev_portal) }}
          - path: /dev-portal
            pathType: Prefix
            backend:
              service:
                name: ray-api-dev-portal
                port:
                  number: 80
{{ end }}
{{ if (and .Values.mainStack.endpoints.entity_store_portal.enabled .enabledRoutes.entityStorePortal) }}
          - path: /sibli-portal
            pathType: Prefix
            backend:
              service:
                name: ray-api-entity-store-portal
                port:
                  number: 80
{{ end }}
{{ if .enabledRoutes.chatbot }}
{{ if .Values.mainStack.endpoints.scenario_bot.enabled }}
          - path: /scenario-chat
            pathType: Prefix
            backend:
              service:
                name: ray-api-scenario-bot
                port:
                  number: 80
          - path: /_nicegui
            pathType: Prefix
            backend:
              service:
                name: ray-api-scenario-bot
                port:
                  number: 80
          - path: /_nicegui_ws
            pathType: Prefix
            backend:
              service:
                name: ray-api-scenario-bot
                port:
                  number: 80
{{ end }}
{{ end }}
{{ if (and .Values.tools.internalMonitoring.enabled .enabledRoutes.internalMonitoring) }}
          - path: {{ .Values.tools.internalMonitoring.caddy.prefix }}
            pathType: Prefix
            backend:
              service:
                name: ray-monitoring
                port:
                  number: 80
{{ end }}
{{- /* API Endpoints */ -}}
{{ if (and .Values.mainStack.endpoints.extractor.enabled .enabledRoutes.extractor) }}
          - path: /extractor
            pathType: Prefix
            backend:
              service:
                name: ray-api-extractor
                port:
                  number: 80
{{ end }}
{{ if (and .Values.mainStack.endpoints.rocketcar.enabled .enabledRoutes.rocketcar) }}
          - path: /api
            pathType: Prefix
            backend:
              service:
                name: ray-api-rocketcar
                port:
                  number: 80
          - path: /docs
            pathType: Prefix
            backend:
              service:
                name: ray-api-rocketcar
                port:
                  number: 80
          - path: /openapi.json
            pathType: Prefix
            backend:
              service:
                name: ray-api-rocketcar
                port:
                  number: 80
{{ end  }}
{{- /* Engineer tooling on rocketcar: /dev/portal and /dev/jobs, super users only.
  Its own route flag, not `rocketcar`: a stack can keep /dev on its tailnet route
  without exposing /api there (prod-g3ak). */ -}}
{{ if (and (not $devToolingStandalone) .Values.mainStack.endpoints.rocketcar.enabled .enabledRoutes.dev) }}
          - path: /dev
            pathType: Prefix
            backend:
              service:
                name: ray-api-rocketcar
                port:
                  number: 80
{{ end }}
{{- /* Entity Store - unsecured version for internal/VPN access */ -}}
{{ if (and .Values.mainStack.endpoints.entity_store.enabled .enabledRoutes.entity_store) }}
          - path: /data/api
            pathType: Prefix
            backend:
              service:
                name: ray-api-entity-store
                port:
                  number: 80
{{ end }}
{{ if (and .Values.mainStack.mcps.rocketcar.enabled .enabledRoutes.mcp_server) }}
          - path: /mcp
            pathType: Prefix
            backend:
              service:
                name: ray-mcp-rocketcar
                port:
                  number: 80
{{ end }}
{{- /* Protected-resource metadata rides the resource server's Service, but it
  only EXISTS when auth is on: the MCP SDK registers the route only when
  AuthSettings.resource_server_url is set. Gated on mcpAuth.enabled, not on the
  route flag, so the path never points at a 404. */ -}}
{{ if (and .Values.mainStack.mcps.rocketcar.enabled .Values.mcpAuth.enabled) }}
          - path: /.well-known/oauth-protected-resource
            pathType: Prefix
            backend:
              service:
                name: ray-mcp-rocketcar
                port:
                  number: 80
{{ end }}
{{- /* MCP OAuth (Hydra) — single origin serves MCP + OAuth. RFC 8414 metadata
  and the DCR sanitizing proxy are served by the rocketcar endpoint; the rest
  of /oauth2 and Hydra's .well-known docs are served by Hydra public. */ -}}
{{ if (and .Values.hydra.enabled .enabledRoutes.hydra) }}
          - path: /oauth2/register
            pathType: Prefix
            backend:
              service:
                name: ray-api-rocketcar
                port:
                  number: 80
          - path: /api/auth/hydra
            pathType: Prefix
            backend:
              service:
                name: ray-api-rocketcar
                port:
                  number: 80
          - path: /.well-known/oauth-authorization-server
            pathType: Prefix
            backend:
              service:
                name: ray-api-rocketcar
                port:
                  number: 80
          - path: /oauth2
            pathType: Prefix
            backend:
              service:
                name: ray-hydra
                port:
                  number: 4444
          - path: /.well-known/openid-configuration
            pathType: Prefix
            backend:
              service:
                name: ray-hydra
                port:
                  number: 4444
          - path: /.well-known/jwks.json
            pathType: Prefix
            backend:
              service:
                name: ray-hydra
                port:
                  number: 4444
{{ end }}
{{- /* Frontend */ -}}
{{ if (and .Values.frontend.enabled .enabledRoutes.frontend) }}
          - path: /
            pathType: Prefix
            backend:
              service:
                name: ray-frontend
                port:
                  number: 80
          - path: /app
            pathType: Prefix
            backend:
              service:
                name: ray-frontend
                port:
                  number: 80
{{ end  }}
{{- /* Public Routes: ONLY secured entity-store API for public internet access */ -}}
{{ if (and .Values.mainStack.endpoints.entity_store_secured.enabled .enabledRoutes.entity_store_secured) }}
          - path: /data/api
            pathType: Prefix
            backend:
              service:
                name: ray-api-entity-store-secured
                port:
                  number: 80
          - path: /api/oauth2
            pathType: Prefix
            backend:
              service:
                name: ray-api-entity-store-secured
                port:
                  number: 80
{{ end }}
{{ end  }}
